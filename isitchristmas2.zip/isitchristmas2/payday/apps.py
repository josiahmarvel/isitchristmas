from django.apps import AppConfig


class Isitchristmas2Config(AppConfig):
    name = 'payday'
